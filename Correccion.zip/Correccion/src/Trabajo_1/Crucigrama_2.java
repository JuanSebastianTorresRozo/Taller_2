/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajo_1;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Crucigrama_2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String[] palabras = new String[5];
        int i = 0;
        do {
            System.out.print("INGRESE LA PALABRA " + (i + 1) + ": ");
            palabras[i] = entrada.nextLine();
            i++;
        } while (i < palabras.length);

        i = 0;
        do {
            System.out.println("Palabra raíz: " + palabras[i]);
            boolean[] letraEncajada = new boolean[palabras[i].length()]; // indica si cada letra de la palabra raíz ya encajó con alguna letra de otra palabra
            int j = 0;
            do {
                if (i == j)
                    continue;
                int k = 0;
                do {
                    char letra = palabras[j].charAt(k);
                    int index = palabras[i].indexOf(letra);
                    if (index != -1 && !letraEncajada[index]) {
                        letraEncajada[index] = true;
                        System.out.println(letra + " encaja con " + palabras[j]);
                        break; // corta el ciclo para esta palabra
                    }
                    k++;
                } while (k < palabras[j].length());
                j++;
            } while (j < palabras.length);
            i++;
        } while (i < palabras.length);
    }
}
